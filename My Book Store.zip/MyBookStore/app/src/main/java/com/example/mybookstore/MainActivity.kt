package com.example.mybookstore

import android.app.ActivityOptions
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Pair
import android.view.View
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var SPLASH_SCREEN: Int = 3000
    var toAnim: Animation? = null
    var im: ImageView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )


        //animtion


        //animtion

        im = findViewById(R.id.logo)


        Handler().postDelayed({
            val intent = Intent(this@MainActivity, PrivacyPolicy::class.java)
            val paris: Array<Pair<*, *>?> = arrayOfNulls(1)
            paris[0] = Pair<View, String>(im, "logo")
            val options = ActivityOptions.makeSceneTransitionAnimation(this@MainActivity)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            startActivity(intent, options.toBundle())
            finish()
        }, SPLASH_SCREEN.toLong())
    }
}