package com.example.mybookstore

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class RequestBook : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_request_book)

        val req=findViewById<Button>(R.id.req)

        req.setOnClickListener {
            val intent = Intent(this@RequestBook, Home::class.java)
            startActivity(intent)
        }
    }
}