package com.example.mybookstore

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView

class Home : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val req=findViewById<Button>(R.id.request)

        val horror=findViewById<ImageView>(R.id.horror)
        val story=findViewById<ImageView>(R.id.story)
        val drama=findViewById<ImageView>(R.id.drama)
        val comedy=findViewById<ImageView>(R.id.comedy)

        horror.setOnClickListener {
            val intent = Intent(this@Home, Horror::class.java)
            startActivity(intent)
        }

        story.setOnClickListener {
            val intent = Intent(this@Home, Story::class.java)
            startActivity(intent)
        }
        drama.setOnClickListener {
            val intent = Intent(this@Home, Drama::class.java)
            startActivity(intent)
        }
        comedy.setOnClickListener {
            val intent = Intent(this@Home, Comedy::class.java)
            startActivity(intent)
        }


        req.setOnClickListener {
            val intent = Intent(this@Home, RequestBook::class.java)
            startActivity(intent)
        }

    }
}