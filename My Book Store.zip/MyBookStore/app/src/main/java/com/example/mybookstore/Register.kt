package com.example.mybookstore

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.mybookstore.data.DBHelper
import com.google.android.material.textfield.TextInputLayout

class Register : AppCompatActivity() {


    var d1: DBHelper? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val reg=findViewById<Button>(R.id.reg)
        val back=findViewById<Button>(R.id.backlog)


        val username=findViewById<TextInputLayout>(R.id.username)
        val password=findViewById<TextInputLayout>(R.id.password1)
        d1 = DBHelper(this)

        back.setOnClickListener(View.OnClickListener {
            val intent = Intent(this@Register, Login::class.java)
            startActivity(intent)
        })
        reg.setOnClickListener(View.OnClickListener {
            val user = username.editText!!.text.toString()
            val pass = password.editText!!.text.toString()
            if (user == "" || pass == null) {
                Toast.makeText(this@Register, "Please fill all the details", Toast.LENGTH_LONG)
                    .show()
            } else {
                val checkUser = d1!!.checkusername(user)
                if (checkUser == false) {
                    val insert = d1!!.insertData(user, pass)
                    if (insert == true) {
                        Toast.makeText(this@Register, "Registered Successfully", Toast.LENGTH_LONG)
                            .show()
                        val intent = Intent(this@Register, Login::class.java)
                        startActivity(intent)
                    } else {
                        Toast.makeText(this@Register, "Registered Failed", Toast.LENGTH_LONG).show()
                    }
                } else {
                    Toast.makeText(this@Register, "User already Exists", Toast.LENGTH_LONG).show()
                }
            }
        })
    }
}