package com.example.mybookstore

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.mybookstore.data.DBHelper
import com.google.android.material.textfield.TextInputLayout

class Login : AppCompatActivity() {
    private var username: TextInputLayout? = null
    private  var password:TextInputLayout? = null


    var d1: DBHelper? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)



        setContentView(R.layout.activity_login)
        val login=findViewById<Button>(R.id.login)
        val create=findViewById<Button>(R.id.signup)


        val username=findViewById<TextInputLayout>(R.id.user_name)
        val password=findViewById<TextInputLayout>(R.id.pass_word)

        d1 = DBHelper(this)
        create.setOnClickListener {
            val intent = Intent(this@Login, Register::class.java)
            startActivity(intent)
        }


        login.setOnClickListener {
            val user = username.editText!!.text.toString()
            val pass = password.editText!!.text.toString()
            if (user == "" || pass == null) {
                Toast.makeText(this@Login, "Please fill all the details", Toast.LENGTH_LONG).show()
            } else {
                val checkUser = d1!!.checkusernamepassword(user,pass)
                if (checkUser) {


                    Toast.makeText(this@Login, "Login Successfully", Toast.LENGTH_LONG).show()
                    val intent = Intent(this@Login, Home::class.java)
                    startActivity(intent)
                }
                else{
                    Toast.makeText(this@Login, "Invailed Crediential", Toast.LENGTH_LONG).show()

                }
            }

        }
    }
}